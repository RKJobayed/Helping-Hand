package com.alamin.helpinghand;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class NewsDetails extends AppCompatActivity {

    ImageView coverImage;
    TextView tvTitle,tvDes;

    public static String TITLE="";
    public static String DESCRIPTION="";
    public static Bitmap MY_BITMAP = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_details);

        coverImage = findViewById(R.id.coverImage);
        tvTitle = findViewById(R.id.tvTitle);
        tvDes = findViewById(R.id.tvDes);

        tvTitle.setText(TITLE);
        tvDes.setText(DESCRIPTION);

        if (MY_BITMAP!=null) coverImage.setImageBitmap(MY_BITMAP);

    }
}