package com.alamin.helpinghand;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class SubmainActivity extends AppCompatActivity {

    ImageView Flat,Maid,Macanics;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submain);

        Flat = findViewById(R.id.Flat);
        Maid = findViewById(R.id.Maid);
        Macanics = findViewById(R.id.Macanics);

        Flat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SubmainActivity.this,FlatActivity.class);
                startActivity(intent);
            }
        });

        Maid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SubmainActivity.this,MaidActivity.class);
                startActivity(intent);
            }
        });

        Macanics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SubmainActivity.this,MacanicsActivity.class);
                startActivity(intent);
            }
        });


    }
}