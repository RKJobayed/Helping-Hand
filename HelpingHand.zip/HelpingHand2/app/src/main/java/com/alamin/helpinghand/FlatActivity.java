package com.alamin.helpinghand;

import android.os.Bundle;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;

import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Random;

public class FlatActivity extends AppCompatActivity {

    ListView listView;
    HashMap<String, String> hashMap = new HashMap<>();
    ArrayList< HashMap<String,String>> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_flat);
        listView = findViewById(R.id.listView);

        createTable();



        MyAdapter myAdapter = new MyAdapter();
        listView.setAdapter(myAdapter);
    }

    //=========================================================================
    //=========================================================================
    //=========================================================================
    class MyAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return arrayList.size();
        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            LayoutInflater inflater = (LayoutInflater) getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View myView = inflater.inflate(R.layout.item, viewGroup,false);

            ImageView itemcover =  myView.findViewById(R.id.itemcover);
            TextView itemCat =  myView.findViewById(R.id.itemCat);
            TextView itemTitle =  myView.findViewById(R.id.itemTitle);
            TextView itemDes =  myView.findViewById(R.id.itemDes);

            LinearLayout layItem = myView.findViewById(R.id.layItem);

            HashMap<String, String> hashMap = arrayList.get(i);
            String cat = hashMap.get("cat");
            String image_url = hashMap.get("image_url");
            String title = hashMap.get("title");
            String des = hashMap.get("des");

            Picasso.get().load(image_url)
                    .placeholder(R.drawable.hmuiuu)
                    .into(itemcover);

            itemCat.setText(cat);
            itemTitle.setText(title);
            itemDes.setText(des);

            Random rnd = new Random();
            int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));
            itemCat.setBackgroundColor(color);

            layItem.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    NewsDetails.TITLE = title;
                    NewsDetails.DESCRIPTION = des;
                    Bitmap bitmap = ((BitmapDrawable) itemcover.getDrawable()).getBitmap();
                    NewsDetails.MY_BITMAP = bitmap;

                    startActivity(new Intent(FlatActivity.this, NewsDetails.class));
                }
            });


            return myView;
        }

    }


    //=========================================================================

    private void createTable(){

        hashMap = new HashMap<>();
        hashMap.put("cat","Shah waliullah r/a, 1kilometer, bahaddarhat, chandgaon, chittagong");
        hashMap.put("image_url","https://varadeal.com/img_product/2/33235e3d066bad95b6eea457826f7507_62bb0778076c7.jpg");
        hashMap.put("title","৳  ১২,০০০ /মাস");
        hashMap.put("des"," ক্যাটাগরি\tফ্যামিলি বাসা\n" +
                "বেডরুম\t২\n" +
                "বাথরুম\t২\n" +
                "ফ্লোর\t১ (তলা)\n" +
                "বিজ্ঞাপনদাতা: Shawon\n" +
                "\n" +
                "চ্যাটিং (বিজ্ঞাপনদাতার সাথে)Active(1 mo ago)\n" +
                "  ফোনে যোগাযগ:  verified number\n" +
                "\n" +
                "01521439595 ");
        arrayList.add(hashMap);





        hashMap = new HashMap<>();
        hashMap.put("cat","গ্রীন টাওয়ার ফ্লাট");
        hashMap.put("image_url","https://scontent.fcgp6-1.fna.fbcdn.net/v/t39.30808-6/297902689_214361137580299_6721602635926336011_n.jpg?_nc_cat=106&ccb=1-7&_nc_sid=5cd70e&_nc_eui2=AeGU4n4pxbsNjFiBShhfhWnCycqA7sF0O97JyoDuwXQ73na-Hr2nVO-rPCxEPJs5tbD6mO4OEQWhRFa_HGQLLXkt&_nc_ohc=aEMXK2r4ASEAX-krZ7h&tn=bpTmeOrX8AUyRIRN&_nc_ht=scontent.fcgp6-1.fna&oh=00_AT-4kThEyWOyRU-YC7_XEop_ATTRHW2QgQk4ZDakH5SY4g&oe=62F77797");
        hashMap.put("title","আধুনিক সুযোগ সুবিধা সম্বলিত ফ্ল্যাট  ভাড়া \n" +
                "১লা সেপ্টেম্বর ২০২২ তারিখ হতে ফ্ল্যাট  ভাড়া দেওয়া হবে। ");
        hashMap.put("des","১০ তলা ভবনের ৮ম তলায়\n" +
                "\uD83D\uDC49২ বেড\n" +
                "\uD83D\uDC49২ বাথ\n" +
                "\uD83D\uDC49আলাদা ড্রয়িং এবং ডাইনিং\n" +
                "\uD83D\uDC49১ কিচেন\n" +
                "\uD83D\uDC49২ বারান্দা \n" +
                "\uD83D\uDC49গ্যাস - সিলিন্ডার গ\u200D্যাস।\n" +
                "\uD83D\uDC49বিদ্যুৎ - পোষ্টপেইড মিটার।\n" +
                "\uD83D\uDC49 পানি -২৪ ঘন্টা।\n" +
                "\uD83D\uDC49ভাড়া ১১,০০০/-\n" +
                "\uD83D\uDC49লিফট সুবিধা। \n" +
                "\uD83D\uDC49ক্লোজসার্কিট ক্যামরা দ্বারা নিয়ন্ত্রিত। \n" +
                "\uD83D\uDC49সর্বক্ষণিক দুইজন সিকিউরিটি গার্ড।\n" +
                "\uD83D\uDC49 পর্যাপ্ত প্রাকৃতিক আলো বাতাসের কারণে বেশীরভাগ সময় বৈদ্যুতিক পাখা চালানো  লাগেনা।\n" +
                "\uD83D\uDC49 ফ্ল্যাটের জানালায় মসকিটো নেট লাগানো আছে। \n" +
                "ঠিকানা : গ্রীন টাওয়ার, তাজউদ্দীন শাহ রোড,\n" +
                "বড় কবরস্থান, রাহাত্তারপুল, চট্টগ্রাম ।\n" +
                "যোগাযোগ:01819942238\n" +
                "সিকিউরিটি:01891516989 ");
        arrayList.add(hashMap);



        hashMap = new HashMap<>();
        hashMap.put("cat","সিডিএ কল্পলোক আবাসিক এলাকা");
        hashMap.put("image_url","https://varadeal.com/img_product/2/33235e3d066bad95b6eea457826f7507_628cc7f7ae485.jpg");
        hashMap.put("title","১ম পর্যায় চটপটির দোকানের দক্ষিণে ( মডেল মসজিদের দক্ষিণে) \n" +
                "৪র্থ তলা বিল্ডিং এর ২য় তলায় ২টি বাসা ভাড়া দেওয়া হবে।");
        hashMap.put("des"," বাসা ভাড়া দেওয়া হবে।\n" +
                "সিডিএ কল্পলোক আবাসিক এলাকা ১ম পর্যায় চটপটির দোকানের দক্ষিণে ( মডেল মসজিদের দক্ষিণে) \n" +
                "৪র্থ তলা বিল্ডিং এর ২য় তলায় ২টি বাসা ভাড়া দেওয়া হবে।\n" +
                "৩ বেড,  ৩ বাথ, ড্রয়িং, ডাইনিং, ২ ব্যালকনি  [১৪০০ বর্গফুট ], চতুর্দিকে আলো বাতাস।\n" +
                "ভাড়া : বাসা প্রতি ১৪,০০০ টাকা ( সিলিন্ডার গ্যাস)\n" +
                "ওয়াসার পানি, পার্কিং এর ব্যবস্থা\n" +
                "বি : দ্র: ভাড়া হবে  সেপ্টেম্বর মাস এর ১ তারিখ  থেকে। \n" +
                "মোবাইল  : 01715146395 ");
        arrayList.add(hashMap);



        hashMap = new HashMap<>();
        hashMap.put("cat","চেয়ারম্যান গাটা, বাহাদ্দারহাট, চট্রগ্রাম");
        hashMap.put("image_url","https://varadeal.com/img_product/fb7b9ffa5462084c5f4e7e85a093e6d7_5b1be4f5d0908.jpg");
        hashMap.put("title","ভাড়া হবে (ছোট বাসা)");
        hashMap.put("des"," ভাড়া হবে (ছোট বাসা)\n" +
                "\uD83C\uDF10 লোকেশন:- এক-কিলোমিটার, যমুনা ক্লাব হতে পশ্চিমে, চেয়ারম্যান গাটা, বাহাদ্দারহাট, চট্রগ্রাম\n" +
                "(ভাড়া ৩৭০০ গ্যাস/বিদ্দুত ছাড়া)\n" +
                "(ভাড়া গ্যাসসহ ৪৫০০ বিদ্দুত ছাড়া)\n" +
                "★১টি বড় রুম- পাকঘর- এটাচ বাথ  \n" +
                "★বন্যামুক্ত বাসা।♦লাইন গ্যাস আছে\n" +
                "★স্টোর হিসেবেও ব্যবহার হতে পারে\n" +
                "★পানি ২৪ঘন্টা।বিদ্যুৎ- প্রি-পেইড মিটার\n" +
                "★চিলিন্ডার ও চুলা কিনতে হবেনা।\n" +
                "চকবাজার, মেডিকেলে যাতায়াত সুবিদা।\n" +
                "☎️ ০১৭৫৪ ৫৫৫ ৬৬০ mito\n ");
        arrayList.add(hashMap);



        hashMap = new HashMap<>();
        hashMap.put("cat","বহদ্দারহাট কাচাঁ বাজারের ");
        hashMap.put("image_url","https://varadeal.com/img_product/2/03c874ab55baa3c1f835d108415fac44_5ee75251a0fb3.jpg");
        hashMap.put("title","House to let");
        hashMap.put("des","আসসালামু আলাইকুম। \n" +
                "চলতি মাস/ সেপ্টেম্বর/অক্টোবর যে কোন একটি মাস থেকে বহদ্দারহাট কাচাঁ বাজারের পাশে ফ্যামিলি ফ্ল্যাট বাসায় সেইফ একটি সাবলেট রুম ভাড়া দেওয়া হবে। অবশ্যই চাকুরীজীবি অথবা স্টুডেন্ট মহিলা হতে হবে। সুন্দর মনোরম পরিবেশে রাস্তার সাথে লাগানো ফ্ল্যাট বাসা। পড়ালিখার যথেষ্ট পরিবেশ ও সেপ্টি আছে।\n" +
                "\uD83D\uDC49বাসার সুবিধাসমূহ:-\n" +
                "১) ২৪ ঘন্টা ওয়াইফাই\n" +
                "২) কারেন্ট প্রি-পেইড মিটার\n" +
                "৩)লাইনের গ্যাস।\n" +
                "৪) ওয়াসার পানি।\n" +
                "বিস্তারিত যোগাযোগঃ- 01818973212  ");
        arrayList.add(hashMap);





        hashMap = new HashMap<>();
        hashMap.put("cat","চাকরিজীবী মেয়ে ফ্লাট");
        hashMap.put("image_url","https://varadeal.com/img_product/2/c359889a833e7612e0cff1dc69d272bc_62a80b9094dbd.jpg");
        hashMap.put("title","মাস থেকে অক্সিজেন মোড় মেইন রোডের পাশে দ্বিতীয় তলায় পর্যাপ্ত আলো বাতাস সমৃদ্ধ  ফ্ল্যাট বাসায় ১ রুম ভাড়া দেওয়া হবে ( ২ রুমের ফ্ল্যাট) । ");
        hashMap.put("des"," বাসায় কোনো ছেলে নাই।\n" +
                "(চাকরিজীবী মেয়ে / ছাত্রী ২ জন এর জন্য)\n" +
                "# মেইন রোড থেকে ৩০ সেকেন্ড লাগে\n" +
                "#২৪ ঘন্টা লিফ্ট সুবিধা \n" +
                "# ফ্রিজের সুযোগ সুবিধা\n" +
                "# ২৪ ঘন্টা পানির সুবিধা \n" +
                "# রুম রেন্ট ৪৫০০ টাকা\n" +
                "# গ্যাস +কারেন্ট আলাদা\n" +
                "# শুধুমাত্র মেয়ে হইলে নক দিবেন। ");
        arrayList.add(hashMap);



        hashMap = new HashMap<>();
        hashMap.put("cat","মোজাফফরনগর সোসাইটি ফ্লাট");
        hashMap.put("image_url","https://varadeal.com/img_product/2/9b1fc5df81cadf52164c02bf92678f95_629c8f8f9ca31.jpg");
        hashMap.put("title","ফ্যামিলি ঘর ভাড়া দেওয়া হবে।");
        hashMap.put("des","(September 1 থেকে)\n" +
                " ↘️৪র্থ তলা সামনের সাইড\n" +
                "✔️3 বেড ,  2 বাথ\n" +
                "✔️ড্রয়িং, ডাইনিং,2 বেলকনি\n" +
                "✔️গ্যাসঃ সিলিন্ডার / বিদ্যুৎঃপ্রিপেইড \n" +
                "❗ভাড়াঃ১২০০০৳\n" +
                " লোকেশন:3 নং গলি (শিশু কবরস্থান এর   উপরে), মোজাফফরনগর সোসাইটি, পলিটেকনিক মোড়\n" +
                "☎️যোগাযোগ : 018617-13770  ");
        arrayList.add(hashMap);




        hashMap = new HashMap<>();
        hashMap.put("cat","আমবাগান ফ্লাট");
        hashMap.put("image_url","https://varadeal.com/img_product/2/b18e8fb514012229891cf024b6436526_6225c44d33ee1.jpg");
        hashMap.put("title","House to let:");
        hashMap.put("des","আসসালামু আলাইকুম। \n" +
                "সেপ্টেম্বর মাস হতে বহদ্দারহাট এর আশেপাশে ফ্যামিলি ফ্ল্যাট বাসায় একটি সেইফ রুমে চাকুরীজীবি বা স্টুডেন্ট অথবা একজন বা দুজন রুমমেট মেয়ে  আবশ্যক।\n" +
                "বাসার সুবিধাসমূহঃ-\n" +
                "১) ২৪ ঘন্টা ওয়াসার পানি।\n" +
                "২) ২৪ ঘন্টা Wifi আছে।\n" +
                "৩) ২৪ ঘন্টা বিদ্যুৎ \n" +
                "৪) লাইনের গ্যাস।\n" +
                "যোগাযোগঃ- 01818973212\n" +
                "বিঃদ্র-ছাত্রী হলে পড়ালিখার যথেষ্ট পরিবেশ আছে।  ");
        arrayList.add(hashMap);




        hashMap = new HashMap<>();
        hashMap.put("cat","Male Roommate Wanted");
        hashMap.put("image_url","https://varadeal.com/img_product/2/acc21473c4525b922286130ffbfe00b5_5ed65e1fd0060.jpg");
        hashMap.put("title","From 1st September 2022, Room will be rent to job holders at 4th floor.");
        hashMap.put("des"," Male Roommate Wanted\n" +
                "From 1st September 2022, Room will be rent to job holders at 4th floor.\n" +
                "Master bed 1 seat available. Attached washroom.\n" +
                "Address:\n" +
                "WADUD AHMED BARI, 3rd FLOOR, (NEAR SHAH AMANOT GARAGE) CHOUMUHUNI, AGRABAD CHATTOGRAM.\n" +
                "Mobile +880 1912-612267 ");
        arrayList.add(hashMap);




        hashMap = new HashMap<>();
        hashMap.put("cat","352,arakan road, badurtala bahaddarhat");
        hashMap.put("image_url","https://varadeal.com/img_product/2/95c8f422f9c3308d391cbcefae21d5ad_5e92b9629b6a6.jpg");
        hashMap.put("title","৳  ৪,০০০ /মাস");
        hashMap.put("des"," ক্যাটাগরি\tসাবলেট / রুম\n" +
                "বেডরুম\t১\n" +
                "বাথরুম\t১\n" +
                "ফ্লোর\t১ (তলা)\n" +
                "আয়তন\t১২ (বর্গফুট) ");
        arrayList.add(hashMap);




        hashMap = new HashMap<>();
        hashMap.put("cat","2 no gate cosmopoliton, Nurul alam sarak");
        hashMap.put("image_url","https://varadeal.com/img_product/2/9b1fc5df81cadf52164c02bf92678f95_629c8f8f9ca31.jpg");
        hashMap.put("title","৳  ৫,৫০০ /মাস");
        hashMap.put("des"," ক্যাটাগরি\tসাবলেট / রুম\n" +
                "বেডরুম\t১\n" +
                "বাথরুম\t১\n" +
                "ফ্লোর\t২ (তলা)\n ");
        arrayList.add(hashMap);




        hashMap = new HashMap<>();
        hashMap.put("cat","Shah waliullah r/a, 1kilometer, bahaddarhat, chandgaon, chittagong");
        hashMap.put("image_url","https://varadeal.com/img_product/2/ccdf3864e2fa9089f9eca4fc7a48ea0a_5e636bfb5114f.jpg");
        hashMap.put("title","৳  ১২,০০০ /মাস");
        hashMap.put("des"," ক্যাটাগরি\tফ্যামিলি বাসা\n" +
                "বেডরুম\t২\n" +
                "বাথরুম\t২\n" +
                "ফ্লোর\t১ (তলা)\n" +
                "বিজ্ঞাপনদাতা: Shawon\n" +
                "\n" +
                "চ্যাটিং (বিজ্ঞাপনদাতার সাথে)Active(1 mo ago)\n" +
                "  ফোনে যোগাযগ:  verified number\n" +
                "\n" +
                "01521439595 ");
        arrayList.add(hashMap);



    }

    //=========================================================================
}

